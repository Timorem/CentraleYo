(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// CentraleYo.js                                                       //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Compteur = new Mongo.Collection("compteur"); //servira à contenir le nb de clics
                                                                       //
if (Meteor.isServer) {                                                 // 3
	if (!Compteur.findOne()) {                                            // 4
		Compteur.insert({ compt: 0, etat: 0 });                              // 6
	}                                                                     //
                                                                       //
	Meteor.publish("compteur", function () {                              // 9
		return Compteur.find({});                                            // 10
	});                                                                   //
}                                                                      //
                                                                       //
if (Meteor.isClient) {                                                 // 14
	Meteor.subscribe("compteur");                                         // 15
                                                                       //
	Template.body.helpers({                                               // 17
		counter: function () {                                               // 18
			return Compteur.findOne().compt;                                    // 19
		}                                                                    //
	});                                                                   //
                                                                       //
	Template.body.helpers({                                               // 24
		etat: function () {                                                  // 25
			return Compteur.findOne().etat;                                     // 26
		}                                                                    //
	});                                                                   //
                                                                       //
	Template.body.helpers({                                               // 31
		counterOver: function (value) {                                      // 32
			//regarde si le nb de clics > value                                 //
			return Compteur.findOne().compt >= value;                           // 33
		}                                                                    //
	});                                                                   //
                                                                       //
	Template.body.helpers({                                               // 37
		counterInbetween: function (valueinf, valuesup, etat) {              // 38
			//regarde si le nb de clics > value                                 //
			return Compteur.findOne().compt >= valueinf && Compteur.findOne().compt < valuesup && Compteur.findOne().etat == etat;
		}                                                                    //
	});                                                                   //
	Template.body.helpers({                                               // 42
		counterExact: function (value, etat) {                               // 43
			//regarde si le nb de clics = value                                 //
			return Compteur.findOne().compt == value;                           // 44
		}                                                                    //
	});                                                                   //
                                                                       //
	Template.body.events({ //on appelle la méthode increment pour incrémenter le compteur
		"click .neb": function () {                                          // 49
			Meteor.call("increment");                                           // 50
		}                                                                    //
	});                                                                   //
                                                                       //
	Template.body.events({                                                // 54
		"click .raz": function () {                                          // 55
			Meteor.call("raz");                                                 // 56
		}                                                                    //
	});                                                                   //
}                                                                      //
                                                                       //
Meteor.methods({                                                       // 61
	increment: function () {                                              // 62
		var count = Compteur.findOne().compt;                                // 63
		var valueEtat = Compteur.findOne().etat;                             // 64
                                                                       //
		if (count == 30 && valueEtat == 0) {                                 // 66
			valueEtat = 1;                                                      // 68
			count = 0;                                                          // 69
		} else if (count == 20 && valueEtat == 1) {                          //
			count = 0;                                                          // 73
			valueEtat = 2;                                                      // 74
		} else if (count == 100 && valueEtat == 2) {                         //
			count = 0;                                                          // 78
			valueEtat = 0;                                                      // 79
		} else {                                                             //
			count++;                                                            // 83
		}                                                                    //
                                                                       //
		Compteur.update({}, { $set: { compt: count, etat: valueEtat } }); //on incrémente le compteur
	},                                                                    //
	raz: function () {                                                    // 88
		Compteur.update({}, { $set: { compt: 0, etat: 0 } }); //on incrémente le compteur
	}                                                                     //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=CentraleYo.js.map
